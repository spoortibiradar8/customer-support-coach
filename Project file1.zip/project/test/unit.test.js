/**
 * Unit Test for Customer Simulator Agent (In-Memory, No Network Sockets)
 */

const assert = require('assert');
const { DEFAULT_PERSONAS } = require('../src/data/personas');
const { DEFAULT_SCENARIOS } = require('../src/data/scenarios');
const { CustomerSimulatorAgent } = require('../src/simulator');
const { EmotionalEngine } = require('../src/engines/emotionalEngine');
const { ScenarioEngine } = require('../src/engines/scenarioEngine');

async function testSimulator() {
  console.log('🧪 Starting Customer Simulator Agent Unit & Scenario Tests...\n');

  // 1. Verify Catalog
  assert(DEFAULT_PERSONAS.length >= 6, 'Should have at least 6 personas');
  assert(DEFAULT_SCENARIOS.length >= 5, 'Should have at least 5 scenarios');
  console.log(`✓ Catalog verified: ${DEFAULT_PERSONAS.length} personas, ${DEFAULT_SCENARIOS.length} scenarios`);

  // 2. Initialize Simulator
  const persona = DEFAULT_PERSONAS.find(p => p.id === 'impatient_executive');
  const scenario = DEFAULT_SCENARIOS.find(s => s.id === 'damaged_delivery');

  const simulator = new CustomerSimulatorAgent({
    persona,
    scenario,
    provider: 'local'
  });

  assert.strictEqual(simulator.history.length, 1, 'Initial history should have opening customer message');
  assert.strictEqual(simulator.history[0].speaker, 'customer');
  console.log(`✓ Session initialized: Turn 0 opening message recorded.`);

  // 3. Turn 1: Empathetic response
  const turn1 = await simulator.processAgentMessage("I am so sorry to hear this! Let me pull up your order ORD-98214 and resolve this immediately.");
  assert.strictEqual(turn1.status, 'active');
  assert(turn1.customerMessage.length > 0, 'Customer should reply');
  assert(turn1.internalMonologue.length > 0, 'Internal monologue should be generated');
  console.log(`✓ Turn 1 (Empathy): Frustration shifted to ${turn1.emotionalState.frustration}% (Deltas: ${JSON.stringify(turn1.emotionalState.deltas)})`);

  // 4. Turn 2: Deflection / Unacceptable offer (testing rage progression)
  const turn2 = await simulator.processAgentMessage("Per company policy, you have to mail the broken pieces back to us and wait 10-14 business days.");
  assert(turn2.emotionalState.deltas.frustration > 0, 'Frustration should spike on policy deflection');
  assert(turn2.emotionalState.triggersDetected.includes('policy_shield'), 'Should detect policy_shield trigger');
  console.log(`✓ Turn 2 (Policy Shield): Frustration spiked to ${turn2.emotionalState.frustration}% (Emotion: ${turn2.emotionalState.primary})`);

  // 5. Turn 3: Full Refund & Apology (De-escalation & Resolution)
  const turn3 = await simulator.processAgentMessage("I completely understand your frustration and I apologize. I have waived the return and processed a full refund of $149.99 right now.");
  assert.strictEqual(turn3.status, 'resolved', 'Status should be resolved after full refund granted');
  assert(turn3.emotionalState.satisfaction >= 80, 'Satisfaction should be high after resolution');
  console.log(`✓ Turn 3 (Full Refund): Status resolved! Satisfaction: ${turn3.emotionalState.satisfaction}%, Frustration: ${turn3.emotionalState.frustration}%`);

  // 6. Evaluation Scorecard
  const evaluation = simulator.evaluate();
  assert(evaluation.csat >= 3.0, 'CSAT should be favorable after resolution');
  assert.strictEqual(evaluation.isResolved, true, 'isResolved should be true');
  assert(evaluation.inflectionPoints.length >= 1, 'Should record inflection points');
  console.log(`✓ Evaluation Scorecard: CSAT ${evaluation.csat} / 5.0, Empathy: ${evaluation.empathyIndex}%, Turns: ${evaluation.totalTurns}`);

  // 7. Test Different Persona Quirks (e.g. Confused Senior Harold Jenkins)
  const seniorPersona = DEFAULT_PERSONAS.find(p => p.id === 'confused_senior');
  const seniorSim = new CustomerSimulatorAgent({
    persona: seniorPersona,
    scenario,
    provider: 'local'
  });
  const seniorTurn1 = await seniorSim.processAgentMessage("Could you please send us a photo of the damage?");
  assert(seniorTurn1.customerMessage.includes('notepad') || seniorTurn1.customerMessage.includes('photos'), 'Harold should answer gently with his notepad anecdote');
  assert.strictEqual(seniorTurn1.newlyDisclosed.length, 1);
  assert.strictEqual(seniorTurn1.newlyDisclosed[0].key, 'photosAvailable');
  console.log(`✓ Persona Voice & Disclosure Test (Harold Jenkins): "${seniorTurn1.customerMessage.slice(0, 95)}..."`);

  console.log('\n🎉 ALL UNIT AND LOGIC TESTS PASSED PERFECTLY!\n');
}

testSimulator().catch(err => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
