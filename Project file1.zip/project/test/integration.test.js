/**
 * Integration Test for Express REST API Routes (Direct Dispatch)
 */

const assert = require('assert');
const { EventEmitter } = require('events');
const { app, sessions } = require('../src/server');

// Helper to simulate HTTP requests into Express without loopback socket
function mockRequest(method, url, body = {}) {
  return new Promise((resolve, reject) => {
    const req = new EventEmitter();
    req.method = method;
    req.url = url;
    req.headers = {
      'content-type': 'application/json',
      'host': 'localhost:3000'
    };
    req.body = body;

    const res = new EventEmitter();
    let resBody = '';
    let statusCode = 200;
    const headers = {};

    res.statusCode = 200;
    res.setHeader = (name, val) => { headers[name.toLowerCase()] = val; };
    res.getHeader = (name) => headers[name.toLowerCase()];
    res.status = (code) => { statusCode = code; res.statusCode = code; return res; };
    res.json = (data) => {
      resolve({ status: statusCode, data });
    };
    res.send = (data) => {
      resolve({ status: statusCode, data });
    };
    res.end = (chunk) => {
      if (chunk) resBody += chunk;
      try {
        resolve({ status: statusCode, data: JSON.parse(resBody) });
      } catch {
        resolve({ status: statusCode, data: resBody });
      }
    };

    app.handle(req, res, (err) => {
      if (err) reject(err);
      else resolve({ status: 404, data: 'Not Found' });
    });
  });
}

async function runApiTests() {
  console.log('🧪 Starting Customer Simulator API Route Tests...\n');

  // 1. Health
  const healthRes = await mockRequest('GET', '/api/health');
  assert.strictEqual(healthRes.status, 200);
  assert.strictEqual(healthRes.data.status, 'ok');
  console.log('✓ GET /api/health passed.');

  // 2. Personas
  const personasRes = await mockRequest('GET', '/api/personas');
  assert.strictEqual(personasRes.status, 200);
  assert(personasRes.data.personas.length >= 6);
  console.log(`✓ GET /api/personas passed (${personasRes.data.personas.length} personas).`);

  // 3. Scenarios
  const scenariosRes = await mockRequest('GET', '/api/scenarios');
  assert.strictEqual(scenariosRes.status, 200);
  assert(scenariosRes.data.scenarios.length >= 5);
  console.log(`✓ GET /api/scenarios passed (${scenariosRes.data.scenarios.length} scenarios).`);

  // 4. Simulator Init
  const initRes = await mockRequest('POST', '/api/simulator/init', {
    persona: 'sarcastic_techie',
    scenario: 'production_api_outage',
    provider: 'local'
  });
  assert.strictEqual(initRes.status, 200);
  assert(initRes.data.sessionId);
  const sessionId = initRes.data.sessionId;
  console.log(`✓ POST /api/simulator/init passed (Session: ${sessionId}).`);

  // 5. Simulator Turn
  const turnRes = await mockRequest('POST', '/api/simulator/turn', {
    sessionId,
    agentMessage: "I see the 502 error on your payment webhooks. I have opened an emergency incident bridge with Tier 2 engineering right now."
  });
  assert.strictEqual(turnRes.status, 200);
  assert(turnRes.data.customerMessage);
  assert(turnRes.data.emotionalState);
  console.log(`✓ POST /api/simulator/turn passed.`);
  console.log(`  Customer: "${turnRes.data.customerMessage}"`);
  console.log(`  Emotional State: ${turnRes.data.emotionalState.primary} (Status: ${turnRes.data.status})`);

  // 6. Simulator Evaluate
  const evalRes = await mockRequest('POST', '/api/simulator/evaluate', { sessionId });
  assert.strictEqual(evalRes.status, 200);
  assert(evalRes.data.evaluation.csat >= 1);
  console.log(`✓ POST /api/simulator/evaluate passed (CSAT: ${evalRes.data.evaluation.csat}⭐).`);

  // 7. Batch Simulation Endpoint
  const batchRes = await mockRequest('POST', '/api/simulator/batch', {
    personaId: 'impatient_executive',
    scenarioId: 'damaged_delivery',
    agentMessages: [
      "Hello! I am so sorry about the damaged item.",
      "I have processed a full refund to your card immediately."
    ]
  });
  assert.strictEqual(batchRes.status, 200);
  assert.strictEqual(batchRes.data.turns.length, 2);
  console.log(`✓ POST /api/simulator/batch passed (${batchRes.data.turns.length} turns processed).`);

  console.log('\n🎉 ALL REST API ROUTE TESTS PASSED PERFECTLY!\n');
}

runApiTests().catch(err => {
  console.error('❌ API test failed:', err);
  process.exit(1);
});
